const List daily = [
  {
    "icon": "assets/images/bank.png",
    "name": "Bank",
    "date": "Fri 10AM",
    "price": "\$340.00"
  },
  {
    "icon": "assets/images/auto.png",
    "name": "Automobile",
    "date": "Mon 8AM",
    "price": "\$70.00"
  },
  {
    "icon": "assets/images/gift.png",
    "name": "Gift",
    "date": "Sat 6PM",
    "price": "\$110.00"
  },
  {
    "icon": "assets/images/eating.png",
    "name": "Eating",
    "date": "Sun 5PM",
    "price": "\$60.00"
  },
  {
    "icon": "assets/images/charity.png",
    "name": "Charity",
    "date": "Wed 12PM",
    "price": "\$1200.00"
  }
];
