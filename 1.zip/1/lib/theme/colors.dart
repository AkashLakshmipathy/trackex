import 'package:flutter/material.dart';

const Color primary = Color(0xFF2C3137);
const Color secondary = Color(0xFF2C3137);
const Color black = Color(0xFF000000);
const Color white = Color(0xFFB1F6EB);
const Color grey = Color(0xFF474747);
const Color red = Color(0xFF474747);
const Color green = Color(0xff43aa8b);
const Color blue = Color(0xFF474747);
const Color errorColor = red;

const Color succses = green;
